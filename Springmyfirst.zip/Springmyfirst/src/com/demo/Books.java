package com.demo;

public class Books {
 int Id ,Price;
 String Publisher;
public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public int getPrice() {
	return Price;
}
public void setPrice(int price) {
	Price = price;
}
public String getPublisher() {
	return Publisher;
}
public void setPublisher(String publisher) {
	Publisher = publisher;
}
void display() {
	System.out.println("Id:"+Id+ "  Price:"+Price+ "  Publisher:"+Publisher);
}
}
