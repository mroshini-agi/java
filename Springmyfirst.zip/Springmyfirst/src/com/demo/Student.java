package com.demo;

public class Student {
	String name,rollno;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRollno() {
		return rollno;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	void display() {
		System.out.println("Name:"+name+  "  Rollno:"+rollno);
	}
}
