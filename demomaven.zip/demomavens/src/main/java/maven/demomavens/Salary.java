package maven.demomavens;
import org.springframework.stereotype.Component;

@Component
public class Salary {

	public Salary() {
		System.out.println("salary: 30000");
	}
	void display()
	{
		System.out.println("Ag");	
	}

}
