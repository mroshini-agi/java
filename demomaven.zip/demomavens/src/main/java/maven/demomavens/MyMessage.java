package maven.demomavens;
 import org.springframework.stereotype.Component;
 
 @Component
 
public class MyMessage {
public MyMessage()
{
	System.out.print("inside constructer....");	
}
void display()
{
	System.out.print("inside method....");	
}
}