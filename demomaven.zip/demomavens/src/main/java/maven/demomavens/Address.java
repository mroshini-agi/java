package maven.demomavens;

import org.springframework.stereotype.Component;

@Component

public class Address {

	public Address() {
		System.out.println("address : Mysore....");	
	}
	void display()
	{
		System.out.println("gayathripuram....");	
	}

	
}
